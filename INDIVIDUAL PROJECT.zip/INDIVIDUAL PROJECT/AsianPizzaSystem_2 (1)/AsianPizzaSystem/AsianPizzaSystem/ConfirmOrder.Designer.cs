﻿namespace AsianPizzaSystem
{
    partial class ConfirmOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConfirmOrder));
            this.confirm = new System.Windows.Forms.Button();
            this.close = new System.Windows.Forms.Button();
            this.totalLabel = new System.Windows.Forms.Label();
            this.orderLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // confirm
            // 
            this.confirm.Location = new System.Drawing.Point(234, 276);
            this.confirm.Name = "confirm";
            this.confirm.Size = new System.Drawing.Size(93, 39);
            this.confirm.TabIndex = 3;
            this.confirm.Text = "Confirm";
            this.confirm.UseVisualStyleBackColor = true;
            this.confirm.Click += new System.EventHandler(this.confirm_click);
            // 
            // close
            // 
            this.close.Location = new System.Drawing.Point(74, 276);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(84, 36);
            this.close.TabIndex = 4;
            this.close.Text = "Go Back";
            this.close.UseVisualStyleBackColor = true;
            this.close.Click += new System.EventHandler(this.Close_Click);
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(214, 85);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(37, 13);
            this.totalLabel.TabIndex = 5;
            this.totalLabel.Text = "Total: ";
            // 
            // orderLabel
            // 
            this.orderLabel.Location = new System.Drawing.Point(6, 16);
            this.orderLabel.Name = "orderLabel";
            this.orderLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.orderLabel.Size = new System.Drawing.Size(309, 69);
            this.orderLabel.TabIndex = 6;
            this.orderLabel.Text = "Order:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.totalLabel);
            this.groupBox1.Controls.Add(this.orderLabel);
            this.groupBox1.Location = new System.Drawing.Point(45, 97);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(321, 120);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Confirm?";
            // 
            // ConfirmOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(397, 395);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.close);
            this.Controls.Add(this.confirm);
            this.Name = "ConfirmOrder";
            this.Text = "Confirm Order";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button confirm;
        private System.Windows.Forms.Button close;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label orderLabel;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}