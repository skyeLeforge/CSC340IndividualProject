﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsianPizzaSystem
{
    public partial class CustomerMenu : Form
    {
        String custID;

        public CustomerMenu(String i)
        {
            custID = i;
            InitializeComponent();
        }

        //Goes to the place Order Screen
        private void PlaceOrder_Click(object sender, EventArgs e)
        {
            
            var myForm = new PlaceOrder(custID);
            myForm.Show();
        }

        //Goes to the order list screen
        private void OrderList_Click(object sender, EventArgs e)
        {
            
            var myForm = new OrderList(custID);
            myForm.Show();
        }

      

        //Goes to edit account menu
        private void EditAccount_Click(object sender, EventArgs e)
        {
            
            var myForm = new EditAccount(custID);
            myForm.Show();
        }

        //Close this menu and return to main
        private void MainMen_Click(object sender, EventArgs e)
        {
            ActiveForm.Close();
        }
    }
}
