﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsianPizzaSystem
{
    public partial class OrderList : Form
    {
        String custID;
        EventArgs e;
        Object sender;
        public OrderList(String i)
        {
            custID = i;
            InitializeComponent();

            loadContent(sender, e);
        }

        //Close menu and return to main
        private void okay_Click(object sender, EventArgs e)
        {
            ActiveForm.Close();
        }

        //Loads the content from dml_stock where there is low stock
        protected void loadContent(object sender, EventArgs e)
        {
            string connStr = "server=csdatabase.eku.edu;user=stu_csc340;database=csc340_db;port=3306;password=Colonels18;sslmode=none";
            MySqlConnection conn = new MySqlConnection(connStr);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("SELECT order_status as 'Status',  order_price as'Price in Dollars',pizza_toppings as 'Toppings', pizza_crust as 'Crust', pizza_size as 'Size', order_amount as 'Amount' FROM leforgeorder where cust_id = '"+custID+"' ORDER BY order_id DESC", conn);
            DataTable dataTable = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dataTable);
            listLowStock.DataSource = dataTable;
            conn.Close();
        }

        
    }
}
