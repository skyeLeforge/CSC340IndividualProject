﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsianPizzaSystem
{
    public partial class MainMenu : Form
    {

        String custID;
        public MainMenu()
        {
            InitializeComponent();
        }


        //Opens the order create account menu
        private void create_account_Click(object sender, EventArgs e)
        {
            
            var myForm = new CreateAccount();
            myForm.Show();
        }

        //Opens the main menu if the email and pass are correct, otherwise tells them they're wrong
        private void log_in_Clicked(object sender, EventArgs e)
        {
            //get the email and password they selected
            String email = email_entry.Text;
            String password = password_entry.Text;

            //connect to the database
            string connStr = "server=csdatabase.eku.edu;user=stu_csc340;database=csc340_db;port=3306;password=Colonels18;sslmode=none";
            MySqlConnection conn = new MySqlConnection(connStr);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("select pass from leforgecustomer where email = '" + email + "';", conn);

            //execute our sql command
            cmd.Prepare();
            MySqlDataReader reader = cmd.ExecuteReader();

            //check if that email is in the database
            if(reader.Read()) { 
                String realPass = reader.GetString(0);

                //check for the correct login information
                if (password == realPass)
                {
                    //get the user id so we can use it later in the program
                    MySqlCommand cmd2 = new MySqlCommand("select customerID from leforgecustomer where email ='" + email+ "';", conn);

                    //execute our sql command
                    reader.Close();
                    cmd2.Prepare();
                    MySqlDataReader reader2 = cmd2.ExecuteReader();
                    reader2.Read();
                    custID = reader2.GetString(0);
                    
                    var myForm = new CustomerMenu(custID);
                    myForm.Show();
                }
                else
                {
                    this.info.Text = "Im sorry, your password was incorrect. Please try again.";
                }
            }
            else
            {
                this.info.Text = "Im sorry, your email was not in the system. Either retype it or create a new account if you dont have one already.";
            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void password_name_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
