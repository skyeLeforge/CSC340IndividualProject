﻿using System.Windows.Forms;

namespace AsianPizzaSystem
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.panel1 = new System.Windows.Forms.Panel();
            this.log_in = new System.Windows.Forms.Button();
            this.create_account = new System.Windows.Forms.Button();
            this.password_name = new System.Windows.Forms.TextBox();
            this.password_entry = new System.Windows.Forms.TextBox();
            this.email_name = new System.Windows.Forms.TextBox();
            this.email_entry = new System.Windows.Forms.TextBox();
            this.info = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.log_in);
            this.panel1.Controls.Add(this.create_account);
            this.panel1.Controls.Add(this.password_name);
            this.panel1.Controls.Add(this.password_entry);
            this.panel1.Controls.Add(this.email_name);
            this.panel1.Controls.Add(this.email_entry);
            this.panel1.Location = new System.Drawing.Point(73, 19);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(164, 355);
            this.panel1.TabIndex = 0;
            // 
            // log_in
            // 
            this.log_in.Location = new System.Drawing.Point(14, 274);
            this.log_in.Name = "log_in";
            this.log_in.Size = new System.Drawing.Size(140, 53);
            this.log_in.TabIndex = 7;
            this.log_in.Text = "Log In";
            this.log_in.UseVisualStyleBackColor = true;
            this.log_in.Click += new System.EventHandler(this.log_in_Clicked);
            // 
            // create_account
            // 
            this.create_account.Location = new System.Drawing.Point(14, 206);
            this.create_account.Name = "create_account";
            this.create_account.Size = new System.Drawing.Size(140, 53);
            this.create_account.TabIndex = 6;
            this.create_account.Text = "Create Account";
            this.create_account.UseVisualStyleBackColor = true;
            this.create_account.Click += new System.EventHandler(this.create_account_Click);
            // 
            // password_name
            // 
            this.password_name.Location = new System.Drawing.Point(14, 59);
            this.password_name.Name = "password_name";
            this.password_name.ReadOnly = true;
            this.password_name.Size = new System.Drawing.Size(140, 20);
            this.password_name.TabIndex = 3;
            this.password_name.Text = "Password";
            this.password_name.TextChanged += new System.EventHandler(this.password_name_TextChanged);
            // 
            // password_entry
            // 
            this.password_entry.Location = new System.Drawing.Point(14, 87);
            this.password_entry.Name = "password_entry";
            this.password_entry.PasswordChar = '*';
            this.password_entry.Size = new System.Drawing.Size(140, 20);
            this.password_entry.TabIndex = 5;
            // 
            // email_name
            // 
            this.email_name.Location = new System.Drawing.Point(14, 7);
            this.email_name.Name = "email_name";
            this.email_name.ReadOnly = true;
            this.email_name.Size = new System.Drawing.Size(140, 20);
            this.email_name.TabIndex = 2;
            this.email_name.Text = "Email";
            // 
            // email_entry
            // 
            this.email_entry.Location = new System.Drawing.Point(14, 33);
            this.email_entry.Name = "email_entry";
            this.email_entry.Size = new System.Drawing.Size(140, 20);
            this.email_entry.TabIndex = 0;
            // 
            // info
            // 
            this.info.Location = new System.Drawing.Point(341, 19);
            this.info.Multiline = true;
            this.info.Name = "info";
            this.info.ReadOnly = true;
            this.info.Size = new System.Drawing.Size(241, 53);
            this.info.TabIndex = 4;
            this.info.Text = "Welcome! Feel free to log in or if you don\'t have an account then press create ac" +
    "count!";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.Window;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(446, 323);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(148, 129);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(594, 488);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.info);
            this.Name = "MainMenu";
            this.Text = "Chang\'s Pizza";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox password_name;
        private System.Windows.Forms.TextBox email_name;
        private System.Windows.Forms.TextBox email_entry;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox info;
        private System.Windows.Forms.TextBox password_entry;
        private System.Windows.Forms.Button create_account;
        private System.Windows.Forms.Button log_in;

    }
}

