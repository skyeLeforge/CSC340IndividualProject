﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsianPizzaSystem
{
    public partial class PlaceOrder : Form
    {
        String custID;

        public PlaceOrder(String i)
        {
            custID = i;
            InitializeComponent();
        }

        
        private void displayTotal_click(object sender, EventArgs e)
        {
            //the order to be saved
            String Order = "";
            String crust;
            String toppings;
            String size;
            int totalPreMultiply = 0;
            int mulBy = 0;
            //find out how many pizzas
            int ammount = (int)quantity.Value;
            if(quantity.Value == 1)
            {
                Order = "A  ";
                mulBy = 1;
            }
            else
            {
                Order = ammount.ToString()+"  ";
                mulBy = ammount;
            }

            //size
            if (small.Checked)
            {
                Order = Order + "small, ";
                size = "small";
                totalPreMultiply += 6;
            }else if (medium.Checked)
            {
                Order = Order + "medium, ";
                totalPreMultiply += 8;
                size = "meduim";
            }
            else
            {
                Order = Order + "large, ";
                totalPreMultiply += 10;
                size = "large";
            }

            //type of crust
            if (thin.Checked)
            {
                Order = Order + "thin crust with ";
                crust = "thin";
            }
            else
            {
                Order = Order + "hand-tossed with ";
                crust = "hand";

            }

            int numTop = 0;
            toppings = "";
            //toppings
            if (pep.Checked)
            {
                toppings = toppings + "peperoni";

                numTop++;
            }

            if (sausage.Checked)
            {
                if(numTop == 0)
                {
                    toppings = toppings + "sausage";
                    numTop++;
                }
                else
                {
                    toppings = toppings + ", sausage";
                    numTop++;
                }
                
            }

            if (bacon.Checked)
            {
                if (numTop == 0)
                {
                    toppings = toppings + "bacon";
                    numTop++;
                }
                else
                {
                    toppings = toppings + ", bacon";
                    numTop++;
                }

            }

            if (pineapple.Checked)
            {
                if (numTop == 0)
                {
                    toppings = toppings + "pineapple";
                    numTop++;
                }
                else
                {
                    toppings = toppings + ", pineapple";
                    numTop++;
                }

            }

            if (ham.Checked)
            { 
                if (numTop == 0)
                {
                    toppings = toppings + "ham";
                    numTop++;
                }
                else
                {
                    toppings = toppings + ", ham";
                    numTop++;
                }

            }

            if (onions.Checked)
            {
                if (numTop == 0)
                {
                    toppings = toppings + "onions";
                    numTop++;
                }
                else
                {
                    toppings = toppings + ", onions";
                    numTop++;
                }

            }

            if (gpeppers.Checked)
            {
                if (numTop == 0)
                {
                    toppings = toppings + "green peppers";
                    numTop++;
                }
                else
                {
                    toppings = toppings + ", green peppers";
                    numTop++;
                }

            }

            if (olives.Checked)
            {
                if (numTop == 0)
                {
                    toppings = toppings + "olives";
                    numTop++;
                }
                else
                {
                    toppings = toppings + ", olives";
                    numTop++;
                }

            }

            if (anchovies.Checked)
            {
                if (numTop == 0)
                {
                    toppings = toppings + "anchovies";
                    numTop++;
                }
                else
                {
                    toppings = toppings + ", anchovies";
                    numTop++;
                }

            }
            if(numTop == 0)
            {
                toppings = "no toppings";
            }

            Order = Order + toppings;

            //calculate how much it will cost
            int total = ammount * (numTop + totalPreMultiply);

            var confirm = new ConfirmOrder(Order, total, custID, ammount, crust, toppings, size);
            confirm.Show();


        }
    }
}
