﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsianPizzaSystem
{
    public partial class ConfirmOrder : Form
    {
        //Needs these objects to load properly
        object sender;
        EventArgs e;

        String Order, crust, toppings, size, custID;
        int total, ammount;

        private void Close_Click(object sender, EventArgs e)
        {
            ActiveForm.Close();
        }

       

        public ConfirmOrder(String o, int t, String c, int a, String cr, String to, String s)
        {
            Order = o;
            total = t;
            custID = c;
            crust = cr;
            toppings = to;
            ammount = a;
            size = s;
            InitializeComponent();

            totalLabel.Text = "Total: $" + t;
            orderLabel.Text = "Order: " + o;
            
        }

       



       

        //Places the Order
        private void confirm_click(object sender, EventArgs e)
        {
            //open a connection
            string connStr = "server=csdatabase.eku.edu;user=stu_csc340;database=csc340_db;port=3306;password=Colonels18;sslmode=none";
            MySqlConnection conn = new MySqlConnection(connStr);
            conn.Open();





            //insert into the customer table
            MySqlCommand cmd = new MySqlCommand("insert into leforgeorder (cust_id, order_Status, pizza_toppings, pizza_crust, pizza_size, order_price, order_amount) values ('" + custID + "', 'Preparing', '" + toppings + "', '" + crust + "', '" + size + "', '" + total + "', '" + ammount + "'); ", conn);
            cmd.ExecuteNonQuery();



            //send them back to the main menu

            ActiveForm.Close();

        }

        

       
    }

}
