﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsianPizzaSystem
{
    public partial class CreateAccount : Form
    {
        //need these for loading the content
        object sender;
        EventArgs e;

        
        public CreateAccount()
        {
            InitializeComponent();
        }

        //is called when they click create account
        private void createNewAccount(object sender, EventArgs e)
        {
            //open a connection
            string connStr = "server=csdatabase.eku.edu;user=stu_csc340;database=csc340_db;port=3306;password=Colonels18;sslmode=none";
            MySqlConnection conn = new MySqlConnection(connStr);
            conn.Open();

            

            

            //insert into the customer table
            MySqlCommand cmd = new MySqlCommand("insert into leforgecustomer (email, name, pass, address, zip, state, city, ccnum, cccvc, ccexp, cczip) values ('"+email.Text+"', '"+name.Text+"', '"+password.Text+"', '"+street.Text+"', '"+zip.Text+"', '"+state.Text+"', '"+city.Text+"', '"+ccnum.Text+"', '"+cccvc.Text+"', '"+ccexp.Text+"', '"+cczip.Text+"' ) ", conn);
            cmd.ExecuteNonQuery();



            //send them back to the main menu

            ActiveForm.Close();



        }

    
    }
}
