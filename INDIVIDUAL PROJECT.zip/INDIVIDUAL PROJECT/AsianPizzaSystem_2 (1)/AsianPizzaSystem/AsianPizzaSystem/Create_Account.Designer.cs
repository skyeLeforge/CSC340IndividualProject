﻿namespace AsianPizzaSystem
{
    partial class CreateAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateAccount));
            this.email = new System.Windows.Forms.TextBox();
            this.create = new System.Windows.Forms.Button();
            this.name = new System.Windows.Forms.TextBox();
            this.street = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.zip = new System.Windows.Forms.TextBox();
            this.state = new System.Windows.Forms.TextBox();
            this.city = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cczip = new System.Windows.Forms.TextBox();
            this.ccexp = new System.Windows.Forms.TextBox();
            this.cccvc = new System.Windows.Forms.TextBox();
            this.ccnum = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(12, 21);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(99, 20);
            this.email.TabIndex = 0;
            this.email.Text = "Email";
            // 
            // create
            // 
            this.create.Location = new System.Drawing.Point(8, 438);
            this.create.Name = "create";
            this.create.Size = new System.Drawing.Size(112, 33);
            this.create.TabIndex = 2;
            this.create.Text = "Create Account";
            this.create.UseVisualStyleBackColor = true;
            this.create.Click += new System.EventHandler(this.createNewAccount);
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(12, 103);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(99, 20);
            this.name.TabIndex = 4;
            this.name.Text = "Name";
            // 
            // street
            // 
            this.street.Location = new System.Drawing.Point(20, 31);
            this.street.Name = "street";
            this.street.Size = new System.Drawing.Size(112, 20);
            this.street.TabIndex = 5;
            this.street.Text = "Street";
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(12, 64);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(99, 20);
            this.password.TabIndex = 6;
            this.password.Text = "Password";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.zip);
            this.groupBox1.Controls.Add(this.state);
            this.groupBox1.Controls.Add(this.city);
            this.groupBox1.Controls.Add(this.street);
            this.groupBox1.Location = new System.Drawing.Point(333, 54);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(152, 327);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Address";
            // 
            // zip
            // 
            this.zip.Location = new System.Drawing.Point(20, 142);
            this.zip.Name = "zip";
            this.zip.Size = new System.Drawing.Size(112, 20);
            this.zip.TabIndex = 8;
            this.zip.Text = "Zip Code";
            // 
            // state
            // 
            this.state.Location = new System.Drawing.Point(20, 103);
            this.state.Name = "state";
            this.state.Size = new System.Drawing.Size(112, 20);
            this.state.TabIndex = 7;
            this.state.Text = "State";
            // 
            // city
            // 
            this.city.Location = new System.Drawing.Point(20, 64);
            this.city.Name = "city";
            this.city.Size = new System.Drawing.Size(112, 20);
            this.city.TabIndex = 6;
            this.city.Text = "City";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.email);
            this.groupBox2.Controls.Add(this.password);
            this.groupBox2.Controls.Add(this.name);
            this.groupBox2.Location = new System.Drawing.Point(21, 54);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(137, 327);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Personal Information";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cczip);
            this.groupBox3.Controls.Add(this.ccexp);
            this.groupBox3.Controls.Add(this.cccvc);
            this.groupBox3.Controls.Add(this.ccnum);
            this.groupBox3.Location = new System.Drawing.Point(181, 54);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(133, 326);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Credit Card Information";
            // 
            // cczip
            // 
            this.cczip.Location = new System.Drawing.Point(17, 142);
            this.cczip.Name = "cczip";
            this.cczip.Size = new System.Drawing.Size(99, 20);
            this.cczip.TabIndex = 3;
            this.cczip.Text = "Zip Code";
            // 
            // ccexp
            // 
            this.ccexp.Location = new System.Drawing.Point(17, 103);
            this.ccexp.Name = "ccexp";
            this.ccexp.Size = new System.Drawing.Size(99, 20);
            this.ccexp.TabIndex = 2;
            this.ccexp.Text = "Expiration Date";
            // 
            // cccvc
            // 
            this.cccvc.Location = new System.Drawing.Point(17, 64);
            this.cccvc.Name = "cccvc";
            this.cccvc.Size = new System.Drawing.Size(99, 20);
            this.cccvc.TabIndex = 1;
            this.cccvc.Text = "Security Code";
            // 
            // ccnum
            // 
            this.ccnum.Location = new System.Drawing.Point(17, 31);
            this.ccnum.Name = "ccnum";
            this.ccnum.Size = new System.Drawing.Size(99, 20);
            this.ccnum.TabIndex = 0;
            this.ccnum.Text = "16 Digit Number";
            // 
            // CreateAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(512, 483);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.create);
            this.Name = "CreateAccount";
            this.Text = "Create Account";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.Button create;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.TextBox street;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox zip;
        private System.Windows.Forms.TextBox state;
        private System.Windows.Forms.TextBox city;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox cczip;
        private System.Windows.Forms.TextBox ccexp;
        private System.Windows.Forms.TextBox cccvc;
        private System.Windows.Forms.TextBox ccnum;
    }
}