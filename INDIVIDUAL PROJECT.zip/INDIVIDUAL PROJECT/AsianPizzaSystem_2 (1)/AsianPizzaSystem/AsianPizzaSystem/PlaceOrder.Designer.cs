﻿namespace AsianPizzaSystem
{
    partial class PlaceOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PlaceOrder));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.quantity = new System.Windows.Forms.NumericUpDown();
            this.displayTotal = new System.Windows.Forms.Button();
            this.medium = new System.Windows.Forms.RadioButton();
            this.Large = new System.Windows.Forms.RadioButton();
            this.small = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.anchovies = new System.Windows.Forms.CheckBox();
            this.olives = new System.Windows.Forms.CheckBox();
            this.pineapple = new System.Windows.Forms.CheckBox();
            this.bacon = new System.Windows.Forms.CheckBox();
            this.gpeppers = new System.Windows.Forms.CheckBox();
            this.onions = new System.Windows.Forms.CheckBox();
            this.ham = new System.Windows.Forms.CheckBox();
            this.sausage = new System.Windows.Forms.CheckBox();
            this.pep = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.thin = new System.Windows.Forms.RadioButton();
            this.handtossed = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.quantity)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.quantity);
            this.panel1.Location = new System.Drawing.Point(21, 68);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(182, 96);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "How Many Pizzas?";
            // 
            // quantity
            // 
            this.quantity.Location = new System.Drawing.Point(30, 59);
            this.quantity.Name = "quantity";
            this.quantity.Size = new System.Drawing.Size(120, 20);
            this.quantity.TabIndex = 7;
            // 
            // displayTotal
            // 
            this.displayTotal.Location = new System.Drawing.Point(386, 461);
            this.displayTotal.Name = "displayTotal";
            this.displayTotal.Size = new System.Drawing.Size(113, 41);
            this.displayTotal.TabIndex = 1;
            this.displayTotal.Text = "Display Total";
            this.displayTotal.UseVisualStyleBackColor = true;
            this.displayTotal.Click += new System.EventHandler(this.displayTotal_click);
            // 
            // medium
            // 
            this.medium.AutoSize = true;
            this.medium.Location = new System.Drawing.Point(47, 62);
            this.medium.Name = "medium";
            this.medium.Size = new System.Drawing.Size(62, 17);
            this.medium.TabIndex = 2;
            this.medium.TabStop = true;
            this.medium.Text = "Medium";
            this.medium.UseVisualStyleBackColor = true;
            // 
            // Large
            // 
            this.Large.AutoSize = true;
            this.Large.Location = new System.Drawing.Point(47, 104);
            this.Large.Name = "Large";
            this.Large.Size = new System.Drawing.Size(52, 17);
            this.Large.TabIndex = 3;
            this.Large.TabStop = true;
            this.Large.Text = "Large";
            this.Large.UseVisualStyleBackColor = true;
            // 
            // small
            // 
            this.small.AutoSize = true;
            this.small.Location = new System.Drawing.Point(47, 23);
            this.small.Name = "small";
            this.small.Size = new System.Drawing.Size(50, 17);
            this.small.TabIndex = 4;
            this.small.TabStop = true;
            this.small.Text = "Small";
            this.small.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.small);
            this.groupBox1.Controls.Add(this.Large);
            this.groupBox1.Controls.Add(this.medium);
            this.groupBox1.Location = new System.Drawing.Point(326, 68);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(159, 147);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Size";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.anchovies);
            this.groupBox2.Controls.Add(this.olives);
            this.groupBox2.Controls.Add(this.pineapple);
            this.groupBox2.Controls.Add(this.bacon);
            this.groupBox2.Controls.Add(this.gpeppers);
            this.groupBox2.Controls.Add(this.onions);
            this.groupBox2.Controls.Add(this.ham);
            this.groupBox2.Controls.Add(this.sausage);
            this.groupBox2.Controls.Add(this.pep);
            this.groupBox2.Location = new System.Drawing.Point(198, 246);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(287, 145);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Toppings";
            // 
            // anchovies
            // 
            this.anchovies.AutoSize = true;
            this.anchovies.Location = new System.Drawing.Point(204, 77);
            this.anchovies.Name = "anchovies";
            this.anchovies.Size = new System.Drawing.Size(76, 17);
            this.anchovies.TabIndex = 11;
            this.anchovies.Text = "Anchovies";
            this.anchovies.UseVisualStyleBackColor = true;
            // 
            // olives
            // 
            this.olives.AutoSize = true;
            this.olives.Location = new System.Drawing.Point(114, 77);
            this.olives.Name = "olives";
            this.olives.Size = new System.Drawing.Size(55, 17);
            this.olives.TabIndex = 10;
            this.olives.Text = "Olives";
            this.olives.UseVisualStyleBackColor = true;
            // 
            // pineapple
            // 
            this.pineapple.AutoSize = true;
            this.pineapple.Location = new System.Drawing.Point(22, 54);
            this.pineapple.Name = "pineapple";
            this.pineapple.Size = new System.Drawing.Size(73, 17);
            this.pineapple.TabIndex = 5;
            this.pineapple.Text = "Pineapple";
            this.pineapple.UseVisualStyleBackColor = true;
            // 
            // bacon
            // 
            this.bacon.AutoSize = true;
            this.bacon.Location = new System.Drawing.Point(204, 28);
            this.bacon.Name = "bacon";
            this.bacon.Size = new System.Drawing.Size(56, 17);
            this.bacon.TabIndex = 9;
            this.bacon.Text = "bacon";
            this.bacon.UseVisualStyleBackColor = true;
            // 
            // gpeppers
            // 
            this.gpeppers.AutoSize = true;
            this.gpeppers.Location = new System.Drawing.Point(22, 77);
            this.gpeppers.Name = "gpeppers";
            this.gpeppers.Size = new System.Drawing.Size(97, 17);
            this.gpeppers.TabIndex = 4;
            this.gpeppers.Text = "Green Peppers";
            this.gpeppers.UseVisualStyleBackColor = true;
            // 
            // onions
            // 
            this.onions.AutoSize = true;
            this.onions.Location = new System.Drawing.Point(204, 54);
            this.onions.Name = "onions";
            this.onions.Size = new System.Drawing.Size(59, 17);
            this.onions.TabIndex = 3;
            this.onions.Text = "Onions";
            this.onions.UseVisualStyleBackColor = true;
            // 
            // ham
            // 
            this.ham.AutoSize = true;
            this.ham.Location = new System.Drawing.Point(114, 54);
            this.ham.Name = "ham";
            this.ham.Size = new System.Drawing.Size(46, 17);
            this.ham.TabIndex = 2;
            this.ham.Text = "ham";
            this.ham.UseVisualStyleBackColor = true;
            // 
            // sausage
            // 
            this.sausage.AutoSize = true;
            this.sausage.Location = new System.Drawing.Point(114, 28);
            this.sausage.Name = "sausage";
            this.sausage.Size = new System.Drawing.Size(68, 17);
            this.sausage.TabIndex = 1;
            this.sausage.Text = "Sausage";
            this.sausage.UseVisualStyleBackColor = true;
            // 
            // pep
            // 
            this.pep.AutoSize = true;
            this.pep.Location = new System.Drawing.Point(22, 28);
            this.pep.Name = "pep";
            this.pep.Size = new System.Drawing.Size(68, 17);
            this.pep.TabIndex = 0;
            this.pep.Text = "Peperoni";
            this.pep.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.thin);
            this.groupBox3.Controls.Add(this.handtossed);
            this.groupBox3.Location = new System.Drawing.Point(21, 246);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(142, 87);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Crust";
            // 
            // thin
            // 
            this.thin.AutoSize = true;
            this.thin.Location = new System.Drawing.Point(6, 52);
            this.thin.Name = "thin";
            this.thin.Size = new System.Drawing.Size(73, 17);
            this.thin.TabIndex = 7;
            this.thin.TabStop = true;
            this.thin.Text = "Thin Crust";
            this.thin.UseVisualStyleBackColor = true;
            // 
            // handtossed
            // 
            this.handtossed.AutoSize = true;
            this.handtossed.Location = new System.Drawing.Point(6, 19);
            this.handtossed.Name = "handtossed";
            this.handtossed.Size = new System.Drawing.Size(89, 17);
            this.handtossed.TabIndex = 8;
            this.handtossed.TabStop = true;
            this.handtossed.Text = "Hand Tossed";
            this.handtossed.UseVisualStyleBackColor = true;
            // 
            // PlaceOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(511, 514);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.displayTotal);
            this.Controls.Add(this.panel1);
            this.Name = "PlaceOrder";
            this.Text = " ";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.quantity)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.NumericUpDown quantity;
        private System.Windows.Forms.Button displayTotal;
        private System.Windows.Forms.RadioButton medium;
        private System.Windows.Forms.RadioButton Large;
        private System.Windows.Forms.RadioButton small;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton thin;
        private System.Windows.Forms.RadioButton handtossed;
        private System.Windows.Forms.CheckBox anchovies;
        private System.Windows.Forms.CheckBox olives;
        private System.Windows.Forms.CheckBox pineapple;
        private System.Windows.Forms.CheckBox bacon;
        private System.Windows.Forms.CheckBox gpeppers;
        private System.Windows.Forms.CheckBox onions;
        private System.Windows.Forms.CheckBox ham;
        private System.Windows.Forms.CheckBox sausage;
        private System.Windows.Forms.CheckBox pep;
    }
}