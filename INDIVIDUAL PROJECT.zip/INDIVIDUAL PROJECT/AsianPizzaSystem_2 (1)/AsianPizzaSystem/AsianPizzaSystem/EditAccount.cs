﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsianPizzaSystem
{
    public partial class EditAccount : Form
    {
        //Needs these objects to load properly
        object sender;
        EventArgs e;

        
        String custID;

        public EditAccount(String i)
        {
            custID = i;
            InitializeComponent();
            loadContent(sender, e);
        }

        //Loads the content from the customer portion of the db
        protected void loadContent(object sender, EventArgs e)
        {
            //set up the conn
            string connStr = "server=csdatabase.eku.edu;user=stu_csc340;database=csc340_db;port=3306;password=Colonels18;sslmode=none";
            MySqlConnection conn = new MySqlConnection(connStr);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM leforgecustomer WHERE customerID = '" +custID+ " ';", conn);
            
            //execute our sql command
            cmd.Prepare();
            MySqlDataReader reader = cmd.ExecuteReader();
            reader.Read();

            //put every saved data for them inot an editable text field
            passwordBox.Text = reader.GetString(1);
            nameBox.Text = reader.GetString(2);
            streetBox.Text = reader.GetString(3);
            stateBox.Text = reader.GetString(4);
            ccNumBox.Text = reader.GetString(5);
            cityBox.Text = reader.GetString(6);
            zipBox.Text = reader.GetString(7);
            emailBox.Text = reader.GetString(8);
            ccCvcBox.Text = reader.GetString(9);
            ccZipBox.Text = reader.GetString(10);
            ccExpBox.Text = reader.GetString(11);




            conn.Close();
        }

       

        

        private void saveBtn_Click(object sender, EventArgs e)
        {
            //Updates your changes
            string connStr = "server=csdatabase.eku.edu;user=stu_csc340;database=csc340_db;port=3306;password=Colonels18;sslmode=none";
            MySqlConnection conn = new MySqlConnection(connStr);
            conn.Open();
            //updating everything
            MySqlCommand cmd = new MySqlCommand("update leforgecustomer SET pass ='"+passwordBox.Text+"'," +
                " name ='"+nameBox.Text+"',address =  '"+streetBox.Text+"', state = '"+stateBox.Text+"', ccnum = '"+ccNumBox.Text+"'," +
                " city = '"+ cityBox.Text+"', zip = '"+zipBox.Text+"', email = '"+emailBox.Text+"', cccvc = '"+ccCvcBox.Text+"'," +
                " cczip = '"+ccZipBox.Text+"', ccexp = '"+ccExpBox.Text+"' WHERE customerID = '"+custID+"';", conn);
            cmd.ExecuteNonQuery();
            conn.Close();

            //boot em back out to the menu
            ActiveForm.Close();
        }

        

        private void GroupBox3_Enter(object sender, EventArgs e)
        {

        }
    }
}
